O arquivo "RealSize-1920x1080_thumbSize-450x253_.png" � repetido no layout com a intens�o de demonstrar uma quantidade de imagens no presskit.
Ent�o, voc� pode colocar mais imagens para download.
Lembre-se de usar nomes diferentes e informar no index.